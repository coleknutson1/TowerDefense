//Test
var myFunction = function(){
	var x = "Hello";
}